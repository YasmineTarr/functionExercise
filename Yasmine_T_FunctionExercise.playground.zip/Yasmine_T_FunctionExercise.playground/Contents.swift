import UIKit

func addingOperation() {
    let a = 1
    let b = 2
    let sum = a + b
    print(sum)
}

 addingOperation()
